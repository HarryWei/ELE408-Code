#!/bin/bash


#index=1;

#for arg in "$*"
for arg in "$@"
do
	echo $arg
	#echo "Arg $index=$arg"
	#echo $arg
	#let "index+=1"
done

#echo $index
