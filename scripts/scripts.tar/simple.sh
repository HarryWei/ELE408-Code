#!/bin/bash

#this is the first one
echo "This is simple example!"
