#!/bin/bash


hello() {
	echo "hello world"
}

hello
