#!/bin/bash

STR="hello world"

echo $STR
