#!/bin/bash

function helloworld() {

	echo $1
	echo $2

set -x

echo "1: Hello World!"
echo "2: Hello World!"
echo "3: Hello World!"
echo "4: Hello World!"
echo "5: Hello World!"
}

helloworld p1 p2
